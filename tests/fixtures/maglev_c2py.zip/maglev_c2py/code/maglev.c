/*
 * File: maglev.c
 *
 * Code generated for Simulink model 'maglev'.
 *
 * Model version                  : 1.7
 * Simulink Coder version         : 25.2 (R2025b) 28-Jul-2025
 * C/C++ source code generated on : Sat Oct  3 15:29:35 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "maglev.h"
#include "rtwtypes.h"
#include "maglev_private.h"

/* Block signals (default storage) */
B_maglev_T maglev_B;

/* Continuous states */
X_maglev_T maglev_X;

/* Disabled State Vector */
XDis_maglev_T maglev_XDis;

/* External inputs (root inport signals with default storage) */
ExtU_maglev_T maglev_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_maglev_T maglev_Y;

/* Real-time model */
static RT_MODEL_maglev_T maglev_M_;
RT_MODEL_maglev_T *const maglev_M = &maglev_M_;

/*
 * This function updates continuous states using the ODE8 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
#define maglev_NSTAGES                 13

  static real_T rt_ODE8_B[13] = {
    4.174749114153025E-2, 0.0, 0.0, 0.0,
    0.0, -5.54523286112393E-2, 2.393128072011801E-1, 7.03510669403443E-1,
    -7.597596138144609E-1, 6.605630309222863E-1, 1.581874825101233E-1,
    -2.381095387528628E-1, 2.5E-1
  };

  static real_T rt_ODE8_C[13] = {
    0.0, 5.555555555555556E-2, 8.333333333333333E-2, 1.25E-1,
    3.125E-1, 3.75E-1, 1.475E-1, 4.65E-1,
    5.648654513822596E-1, 6.5E-1, 9.246562776405044E-1, 1.0, 1.0
  };

  static real_T rt_ODE8_A[13][13] = {
    /* rt_ODE8_A[0][] */
    { 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0 },

    /* rt_ODE8_A[1][] */
    { 5.555555555555556E-2, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0 },

    /* rt_ODE8_A[2][] */
    { 2.083333333333333E-2, 6.25E-2, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0 },

    /* rt_ODE8_A[3][] */
    { 3.125E-2, 0.0, 9.375E-2, 0.0,
      0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0 },

    /* rt_ODE8_A[4][] */
    { 3.125E-1, 0.0, -1.171875, 1.171875,
      0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0 },

    /* rt_ODE8_A[5][] */
    { 3.75E-2, 0.0, 0.0, 1.875E-1,
      1.5E-1, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0 },

    /* rt_ODE8_A[6][] */
    { 4.791013711111111E-2, 0.0, 0.0, 1.122487127777778E-1,
      -2.550567377777778E-2, 1.284682388888889E-2, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0 },

    /* rt_ODE8_A[7][] */
    { 1.691798978729228E-2, 0.0, 0.0, 3.878482784860432E-1,
      3.597736985150033E-2, 1.969702142156661E-1, -1.727138523405018E-1, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0 },

    /* rt_ODE8_A[8][] */
    { 6.90957533591923E-2, 0.0, 0.0, -6.342479767288542E-1,
      -1.611975752246041E-1, 1.386503094588253E-1, 9.409286140357563E-1,
      2.11636326481944E-1,
      0.0, 0.0, 0.0, 0.0, 0.0 },

    /* rt_ODE8_A[9][] */
    { 1.835569968390454E-1, 0.0, 0.0, -2.468768084315592,
      -2.912868878163005E-1, -2.647302023311738E-2, 2.8478387641928,
      2.813873314698498E-1,
      1.237448998633147E-1, 0.0, 0.0, 0.0, 0.0 },

    /* rt_ODE8_A[10][] */
    { -1.215424817395888, 0.0, 0.0, 1.667260866594577E1,
      9.157418284168179E-1, -6.056605804357471, -1.600357359415618E1,
      1.484930308629766E1,
      -1.337157573528985E1, 5.134182648179638, 0.0, 0.0, 0.0 },

    /* rt_ODE8_A[11][] */
    { 2.588609164382643E-1, 0.0, 0.0, -4.774485785489205,
      -4.350930137770325E-1, -3.049483332072241, 5.577920039936099,
      6.155831589861039,
      -5.062104586736938, 2.193926173180679, 1.346279986593349E-1, 0.0, 0.0 },

    /* rt_ODE8_A[12][] */
    { 8.224275996265075E-1, 0.0, 0.0, -1.165867325727766E1,
      -7.576221166909362E-1, 7.139735881595818E-1, 1.207577498689006E1,
      -2.127659113920403,
      1.990166207048956, -2.342864715440405E-1, 1.758985777079423E-1, 0.0, 0.0 },
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE8_IntgData *intgData = (ODE8_IntgData *)rtsiGetSolverData(si);
  real_T *deltaY = intgData->deltaY;
  real_T *x0 = intgData->x0;
  real_T* f[maglev_NSTAGES];
  int_T idx,stagesIdx,statesIdx;
  real_T deltaX;
  int_T nXc = 3;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);
  f[0] = intgData->f[0];
  f[1] = intgData->f[1];
  f[2] = intgData->f[2];
  f[3] = intgData->f[3];
  f[4] = intgData->f[4];
  f[5] = intgData->f[5];
  f[6] = intgData->f[6];
  f[7] = intgData->f[7];
  f[8] = intgData->f[8];
  f[9] = intgData->f[9];
  f[10] = intgData->f[10];
  f[11] = intgData->f[11];
  f[12] = intgData->f[12];

  /* Save the state values at time t in y and x0*/
  (void) memset(deltaY, 0,
                (uint_T)nXc*sizeof(real_T));
  (void) memcpy(x0, x,
                nXc*sizeof(real_T));
  for (stagesIdx=0;stagesIdx<maglev_NSTAGES;stagesIdx++) {
    (void) memcpy(x, x0,
                  (uint_T)nXc*sizeof(real_T));
    for (statesIdx=0;statesIdx<nXc;statesIdx++) {
      deltaX = 0;
      for (idx=0;idx<stagesIdx;idx++) {
        deltaX = deltaX + h*rt_ODE8_A[stagesIdx][idx]*f[idx][statesIdx];
      }

      x[statesIdx] = x0[statesIdx] + deltaX;
    }

    if (stagesIdx==0) {
      rtsiSetdX(si, f[stagesIdx]);
      maglev_derivatives();
    } else {
      (stagesIdx==maglev_NSTAGES-1)? rtsiSetT(si, tnew) : rtsiSetT(si, t + h*
          rt_ODE8_C[stagesIdx]);
      rtsiSetdX(si, f[stagesIdx]);
      maglev_output();
      maglev_derivatives();
    }

    for (statesIdx=0;statesIdx<nXc;statesIdx++) {
      deltaY[statesIdx] = deltaY[statesIdx] + h*rt_ODE8_B[stagesIdx]*f[stagesIdx]
        [statesIdx];
    }
  }

  for (statesIdx=0;statesIdx<nXc;statesIdx++) {
    x[statesIdx] = x0[statesIdx] + deltaY[statesIdx];
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model output function */
void maglev_output(void)
{
  real_T pos;
  int32_T i;
  if (rtmIsMajorTimeStep(maglev_M)) {
    /* set solver stop time */
    rtsiSetSolverStopTime(&maglev_M->solverInfo,((maglev_M->Timing.clockTick0+1)*
      maglev_M->Timing.stepSize0));
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(maglev_M)) {
    maglev_M->Timing.t[0] = rtsiGetT(&maglev_M->solverInfo);
  }

  for (i = 0; i < 3; i++) {
    /* Integrator: '<Root>/Integrator' */
    pos = maglev_X.Integrator_CSTATE[i];
    maglev_B.Integrator[i] = pos;

    /* Outport: '<Root>/Out1' */
    maglev_Y.Out1[i] = pos;
  }

  /* MATLAB Function: '<Root>/MATLAB Function' incorporates:
   *  Inport: '<Root>/In1'
   */
  /*  Nonlinear magnetic levitation system dynamics */
  /* :  m = 0.05; */
  /* :  K = 1e-4; */
  /* :  L = 0.01; */
  /* :  R = 1.0; */
  /* :  g = 9.81; */
  /* :  pos = x(1); */
  pos = maglev_B.Integrator[0];

  /* :  vel = x(2); */
  /* :  curr = x(3); */
  /* :  volts = u(1); */
  /*  Safeguard to prevent division by zero at origin */
  /* :  if pos < 1e-4 */
  if (maglev_B.Integrator[0] < 0.0001) {
    /* :  pos = 1e-4; */
    pos = 0.0001;
  }

  /* :  dx1 = vel; */
  /* :  dx2 = g - (K / m) * (curr^2 / pos^2); */
  /* :  dx3 = (volts - R * curr) / L; */
  /* :  dx = [dx1; dx2; dx3]; */
  maglev_B.dx[0] = maglev_B.Integrator[1];
  maglev_B.dx[1] = 9.81 - maglev_B.Integrator[2] * maglev_B.Integrator[2] / (pos
    * pos) * 0.002;
  maglev_B.dx[2] = (maglev_U.In1 - maglev_B.Integrator[2]) / 0.01;

  /* End of MATLAB Function: '<Root>/MATLAB Function' */
}

/* Model update function */
void maglev_update(void)
{
  if (rtmIsMajorTimeStep(maglev_M)) {
    rt_ertODEUpdateContinuousStates(&maglev_M->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  ++maglev_M->Timing.clockTick0;
  maglev_M->Timing.t[0] = rtsiGetSolverStopTime(&maglev_M->solverInfo);

  {
    /* Update absolute timer for sample time: [0.01s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The resolution of this integer timer is 0.01, which is the step size
     * of the task. Size of "clockTick1" ensures timer will not overflow during the
     * application lifespan selected.
     */
    maglev_M->Timing.clockTick1++;
  }
}

/* Derivatives for root system: '<Root>' */
void maglev_derivatives(void)
{
  XDot_maglev_T *_rtXdot;
  int32_T i;
  _rtXdot = ((XDot_maglev_T *) maglev_M->derivs);

  /* Derivatives for Integrator: '<Root>/Integrator' */
  for (i = 0; i < 3; i++) {
    _rtXdot->Integrator_CSTATE[i] = maglev_B.dx[i];
  }

  /* End of Derivatives for Integrator: '<Root>/Integrator' */
}

/* Model initialize function */
void maglev_initialize(void)
{
  /* Registration code */
  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&maglev_M->solverInfo, &maglev_M->Timing.simTimeStep);
    rtsiSetTPtr(&maglev_M->solverInfo, &rtmGetTPtr(maglev_M));
    rtsiSetStepSizePtr(&maglev_M->solverInfo, &maglev_M->Timing.stepSize0);
    rtsiSetdXPtr(&maglev_M->solverInfo, &maglev_M->derivs);
    rtsiSetContStatesPtr(&maglev_M->solverInfo, (real_T **)
                         &maglev_M->contStates);
    rtsiSetNumContStatesPtr(&maglev_M->solverInfo,
      &maglev_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&maglev_M->solverInfo,
      &maglev_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&maglev_M->solverInfo,
      &maglev_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&maglev_M->solverInfo,
      &maglev_M->periodicContStateRanges);
    rtsiSetContStateDisabledPtr(&maglev_M->solverInfo, (boolean_T**)
      &maglev_M->contStateDisabled);
    rtsiSetErrorStatusPtr(&maglev_M->solverInfo, (&rtmGetErrorStatus(maglev_M)));
    rtsiSetRTModelPtr(&maglev_M->solverInfo, maglev_M);
  }

  rtsiSetSimTimeStep(&maglev_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetIsMinorTimeStepWithModeChange(&maglev_M->solverInfo, false);
  rtsiSetIsContModeFrozen(&maglev_M->solverInfo, false);
  maglev_M->intgData.deltaY= maglev_M->OdeDeltaY;
  maglev_M->intgData.f[0] = maglev_M->odeF[0];
  maglev_M->intgData.f[1] = maglev_M->odeF[1];
  maglev_M->intgData.f[2] = maglev_M->odeF[2];
  maglev_M->intgData.f[3] = maglev_M->odeF[3];
  maglev_M->intgData.f[4] = maglev_M->odeF[4];
  maglev_M->intgData.f[5] = maglev_M->odeF[5];
  maglev_M->intgData.f[6] = maglev_M->odeF[6];
  maglev_M->intgData.f[7] = maglev_M->odeF[7];
  maglev_M->intgData.f[8] = maglev_M->odeF[8];
  maglev_M->intgData.f[9] = maglev_M->odeF[9];
  maglev_M->intgData.f[10] = maglev_M->odeF[10];
  maglev_M->intgData.f[11] = maglev_M->odeF[11];
  maglev_M->intgData.f[12] = maglev_M->odeF[12];
  maglev_M->intgData.x0 = maglev_M->odeX0;
  maglev_M->contStates = ((X_maglev_T *) &maglev_X);
  maglev_M->contStateDisabled = ((XDis_maglev_T *) &maglev_XDis);
  maglev_M->Timing.tStart = (0.0);
  rtsiSetSolverData(&maglev_M->solverInfo, (void *)&maglev_M->intgData);
  rtsiSetSolverName(&maglev_M->solverInfo,"ode8");
  rtmSetTPtr(maglev_M, &maglev_M->Timing.tArray[0]);
  maglev_M->Timing.stepSize0 = 0.01;

  {
    int32_T i;

    /* InitializeConditions for Integrator: '<Root>/Integrator' */
    for (i = 0; i < 3; i++) {
      maglev_X.Integrator_CSTATE[i] = maglev_P.Integrator_IC[i];
    }

    /* End of InitializeConditions for Integrator: '<Root>/Integrator' */
  }
}

/* Model terminate function */
void maglev_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
