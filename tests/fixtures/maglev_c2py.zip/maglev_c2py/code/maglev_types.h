/*
 * File: maglev_types.h
 *
 * Code generated for Simulink model 'maglev'.
 *
 * Model version                  : 1.7
 * Simulink Coder version         : 25.2 (R2025b) 28-Jul-2025
 * C/C++ source code generated on : Sat Oct  3 15:29:35 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef maglev_types_h_
#define maglev_types_h_

/* Parameters (default storage) */
typedef struct P_maglev_T_ P_maglev_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_maglev_T RT_MODEL_maglev_T;

#endif                                 /* maglev_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
