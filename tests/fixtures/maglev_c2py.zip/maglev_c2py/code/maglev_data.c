/*
 * File: maglev_data.c
 *
 * Code generated for Simulink model 'maglev'.
 *
 * Model version                  : 1.7
 * Simulink Coder version         : 25.2 (R2025b) 28-Jul-2025
 * C/C++ source code generated on : Sat Oct  3 15:29:35 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "maglev.h"

/* Block parameters (default storage) */
P_maglev_T maglev_P = {
  /* Expression: [0.05; 0; 0]
   * Referenced by: '<Root>/Integrator'
   */
  { 0.05, 0.0, 0.0 }
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
